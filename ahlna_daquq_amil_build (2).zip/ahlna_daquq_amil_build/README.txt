﻿تعليمات تشغيل تطبيق الأدمن:
1) ثبّت المتطلبات: requirements\\install_requirements.bat كمسؤول.
2) ضع مفتاح خدمة Supabase في requirements\\supabase_service_key.txt (سطر واحد).
3) شغّل ahlna_daquq.exe.
إذا ظهر خطأ VCRUNTIME140_1.dll، ثبّت vc_redist.x64/x86 من requirements.
